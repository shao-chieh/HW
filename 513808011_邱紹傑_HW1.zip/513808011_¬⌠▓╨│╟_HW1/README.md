---
title: HWO1-513808011

---

# HWO1-513808011

## which tasks you have completed

(25%) Correctly complete the line algorithm.

(25%) Correctly complete the circle algorithm.

(15%) Correctly complete the ellipse algorithm.

(15%) Correctly complete the curve algorithm.

(20%) Correctly complete the eraser.

### some screenshots of your work

![LINE](https://hackmd.io/_uploads/HJxFPO1lkx.png)
![LINE指令](https://hackmd.io/_uploads/HyOKvOJl1g.png)
![曲線指令](https://hackmd.io/_uploads/SJH5wu1eJl.png)
![橡皮擦指令](https://hackmd.io/_uploads/Skp5Pukl1x.png)

#### how you completed these tasks

使用ChatGPT輔助完成作業，規避禁止使用的語法，選擇其它語法結構完成指定動作指令。

動作指令異常，再細部微調，例如曲線一開始為多點分布，增加點為數量後才看起來才有線條感。